# 上传到 GitHub 并开启每日自动更新

目标：让页面在每天北京时间 9:30 自动更新，网址形如
`https://<你的用户名>.github.io/<仓库名>/`

全程不需要服务器，不需要命令行（可选），大约 5 分钟。

---

## 第一步：创建仓库

1. 打开 https://github.com/new
2. **Repository name** 填一个名字，例如 `ai-industry-map`
3. 可见性选 **Public**
   （免费账号的 Pages 只支持 Public 仓库；Private 需要付费计划）
4. **不要**勾选 "Add a README file"、"Add .gitignore"、"Choose a license"
   （保持空仓库，避免和上传的文件冲突）
5. 点 **Create repository**

---

## 第二步：上传文件

创建后页面会显示一个空仓库。点 **uploading an existing file**（或直接访问
`https://github.com/<用户名>/<仓库名>/upload/main`）。

把 `repo-pkg/` 里的**全部内容**拖进去，包括：

```
.github/workflows/daily-update.yml
.gitignore
ai-industry-map.html
index.html
ai_daily_report.py
report_to_news.py
daily_update.py
news.json
reports/ai-daily-20261115.md
```

⚠️ 两个容易出错的地方：

- **`.github` 是隐藏目录**。在 Windows 资源管理器里默认不显示，Mac Finder 里按
  `Cmd+Shift+.` 才显示。如果拖拽时它被漏掉，工作流就不会运行。
  最稳妥的办法：把 `repo-pkg` 打成 zip 上传后解压，或用下面的命令行方式。
- **目录结构必须保留**。`daily-update.yml` 必须在
  `.github/workflows/` 下，不能直接放在根目录。

上传完成后点 **Commit changes**。

### 如果拖拽总是丢隐藏目录，用命令行（推荐）

```bash
cd repo-pkg
git init
git add -A
git commit -m "初始化：AI 产业地图"
git branch -M main
git remote add origin https://github.com/<用户名>/<仓库名>.git
git push -u origin main
```

推送时会要求登录。GitHub 已不支持密码，需要用 **Personal Access Token**：
`Settings → Developer settings → Personal access tokens → Tokens (classic) → Generate new token`，
勾选 `repo` 权限，把生成的 token 当作密码粘贴。

---

## 第三步：开启 Actions 写权限

**这一步不做，工作流会在提交那一步失败。**

1. 进入仓库 → **Settings**（顶部标签栏）
2. 左侧 → **Actions** → **General**
3. 拉到最下面 **Workflow permissions**
4. 选 **Read and write permissions**
5. 点 **Save**

---

## 第四步：开启 Pages

1. 仓库 → **Settings** → 左侧 **Pages**
2. **Source** 选 **Deploy from a branch**
3. **Branch** 选 `main`，**Folder** 选 `/ (root)`
4. 点 **Save**

保存后页面顶部会出现提示，告诉你站点地址。首次部署需要 1–2 分钟。

---

## 第五步：手动跑一次验证

1. 仓库 → **Actions** 标签
2. 左侧选 **每日更新 AI 产业信息**
3. 右侧 **Run workflow** → 再点绿色的 **Run workflow**
4. 等约 30 秒，刷新页面，应该出现一次运行记录

点进去看每一步：

- **抓取并生成日报**：日志里应有「完成：N 条候选，精选 5 条」
- **检查产出**：应显示「条目数：8」这类信息
- **提交变更**：应显示提交成功

如果「提交变更」报 `Permission denied`，说明第三步没做或没生效。

---

## 第六步：访问页面

打开 `https://<用户名>.github.io/<仓库名>/`

确认页面底部「数据窗口」显示的是当天的时间段。

---

## 时间说明

工作流里写的是：

```yaml
- cron: '30 1 * * *'
```

**GitHub Actions 的 cron 一律按 UTC 计算，不支持本地时区。**
UTC 01:30 = 北京时间 09:30。

如果你想改成别的北京时间：

| 北京时间 | UTC | cron 写法 |
|---|---|---|
| 09:30 | 01:30 | `30 1 * * *` |
| 08:00 | 00:00 | `0 0 * * *` |
| 12:00 | 04:00 | `0 4 * * *` |

改法：在 GitHub 网页上打开 `.github/workflows/daily-update.yml`，点铅笔图标编辑，
改完 Commit 即可。

---

## 必须知道的两点局限

1. **不保证准点。** GitHub 官方文档明确说明定时任务可能延迟，高峰期延迟几十分钟
   也发生过。要精确 9:30 只能自建服务器跑 cron。
2. **仓库 60 天无提交会自动暂停定时任务。** 这个工作流每天提交 `news.json`，
   所以会持续活跃；但如果连续多天抓取失败（不产生提交），可能被暂停。
   到时进 Actions 页面点一次启用即可。

---

## 常见问题

**Q：Actions 里看不到工作流？**
`.github/workflows/daily-update.yml` 没上传成功。检查仓库根目录下是否有
`.github` 这个文件夹，点进去确认 `workflows/daily-update.yml` 存在。

**Q：页面打开是 404？**
Pages 还没部署完，等 1–2 分钟；或第四步的 Source 没保存成功。

**Q：页面能打开，但数据不更新？**
看 Actions 的运行记录。若「检查产出」报「条目数 < 3」，说明当天抓取异常，
脚本按设计保留了旧数据。日志里会写明是哪个源失败。

**Q：想立刻更新一次？**
Actions → 每日更新 AI 产业信息 → Run workflow。

**Q：Private 仓库能用吗？**
Pages 在免费账号下只支持 Public。要私有仓库就得升级付费计划，
或改用 Cloudflare Pages / Vercel 等支持私有仓库的托管。

---

## 本地先验证（可选）

不用 GitHub 也能先跑一遍，确认脚本在你机器上正常：

```bash
cd repo-pkg
python3 daily_update.py
```

需要 Python 3.8+，不依赖任何第三方包。
成功会输出「更新完成：N 条」，并更新 `news.json` 和页面的内联数据。