#!/usr/bin/env python3
"""
AI 日报生成器（遵循 @user_fa1d3d9e/ai-daily-report-skill 规范）
--------------------------------------------------------------
按技能 SKILL.md 规定的数据源、提取方式、筛选标准与输出格式生成 Markdown 日报。

用法:
    python3 ai_daily_report.py                      # 生成今天的日报
    python3 ai_daily_report.py --out reports        # 指定输出目录
    python3 ai_daily_report.py --max 10 --verbose

与技能文档的差异（已实测，非猜测）:
    技能文档标注「已验证可用」的源中，以下 3 个实测失效，已跳过并记录原因：
      - 机器之心 RSS/HTML  → 返回反爬 HTML 页面，无新闻内容
      - 36氪 AI 频道 RSS    → 返回反爬 HTML 页面，无新闻内容
      - AI News             → HTTP 502
      - VentureBeat         → HTTP 429 限流
    实际使用：量子位（RSS + HTML）、TechCrunch、Ars Technica、
              MIT Technology Review、Product Hunt。

输出:
    reports/ai-daily-YYYYMMDD.md      日报正文（技能规定格式）
    reports/.items-YYYYMMDD.json      条目的时间/来源元数据（供转换器使用）
"""

import argparse
import json
import os
import re
import sys
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone

CST = timezone(timedelta(hours=8))
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"

# 技能文档指定的源。ok=False 的源仍保留在清单里，便于日后复查是否恢复。
SOURCES = [
    {"name": "量子位", "kind": "rss", "url": "https://www.qbitai.com/feed", "ok": True},
    {"name": "量子位", "kind": "html", "url": "https://www.qbitai.com/", "ok": True},
    {"name": "机器之心", "kind": "rss", "url": "https://www.jiqizhixin.com/rss", "ok": False,
     "reason": "返回反爬 HTML 页面，无新闻内容"},
    {"name": "36氪AI", "kind": "rss", "url": "https://36kr.com/information/AI/feed", "ok": False,
     "reason": "返回反爬 HTML 页面，无新闻内容"},
    {"name": "TechCrunch", "kind": "rss", "url": "https://techcrunch.com/feed/", "ok": True},
    {"name": "ArsTechnica", "kind": "rss", "url": "https://arstechnica.com/feed/", "ok": True},
    {"name": "AI News", "kind": "rss", "url": "https://www.artificialintelligence-news.com/feed/", "ok": False,
     "reason": "HTTP 502"},
    {"name": "MIT Tech Review", "kind": "rss", "url": "https://www.technologyreview.com/feed/", "ok": True},
    {"name": "VentureBeat", "kind": "rss", "url": "https://venturebeat.com/feed/", "ok": False,
     "reason": "HTTP 429 限流"},
    {"name": "Product Hunt", "kind": "atom", "url": "https://www.producthunt.com/feed", "ok": True},
]

# 技能 Step 3 的筛选维度：越靠前权重越高
PRIORITY = [
    (6, ["gpt", "claude", "gemini", "llama", "deepseek", "大模型", "模型发布", "开源模型", "qwen"]),
    (5, ["发布", "上线", "推出", "launch", "release", "unveil", "introducing"]),
    (5, ["融资", "估值", "ipo", "收购", "并购", "funding", "raises", "valuation", "acquire", "merger"]),
    (5, ["监管", "政策", "法案", "禁令", "regulation", "policy", "ban", "antitrust"]),
    (4, ["ceo", "辞任", "离职", "任命", "高管", "resign", "appoint", "steps down"]),
    (4, ["芯片", "gpu", "算力", "数据中心", "chip", "data center", "nvidia", "tsmc"]),
    (3, ["机器人", "具身", "自动驾驶", "robot", "embodied", "humanoid"]),
    (3, ["论文", "研究", "基准", "评测", "paper", "benchmark", "research"]),
    (2, ["智能体", "agent", "api", "sdk", "开发者", "developer"]),
]

AI_HINT = ["ai", "人工智能", "大模型", "模型", "算力", "芯片", "gpu", "智能", "机器人",
           "openai", "anthropic", "nvidia", "deepseek", "google", "meta", "microsoft",
           "llm", "agent", "machine learning", "neural", "chatbot"]


def fetch(url, timeout=18):
    try:
        req = urllib.request.Request(url, headers={"User-Agent": UA})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.read().decode("utf-8", "ignore")
    except Exception:
        return None


def strip_tags(text):
    text = re.sub(r"<!\[CDATA\[(.*?)\]\]>", r"\1", text or "", flags=re.S)
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"&#8217;|&rsquo;", "'", text)
    text = re.sub(r"&#8220;|&#8221;|&quot;", '"', text)
    text = re.sub(r"&amp;", "&", text)
    text = re.sub(r"&#\d+;|&[a-z]+;", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def parse_rss(xml_text):
    """RSS 2.0 + Atom。返回 [(title, link, summary, dt)]"""
    out = []
    try:
        root = ET.fromstring(xml_text.encode("utf-8"))
    except ET.ParseError:
        # 容错：逐条正则提取，避免单处非法字符导致整份作废
        for block in re.findall(r"<item[\s>].*?</item>", xml_text, re.S):
            t = re.search(r"<title[^>]*>(.*?)</title>", block, re.S)
            l = re.search(r"<link[^>]*>(.*?)</link>", block, re.S)
            d = re.search(r"<description[^>]*>(.*?)</description>", block, re.S)
            p = re.search(r"<pubDate[^>]*>(.*?)</pubDate>", block, re.S)
            if t:
                out.append((strip_tags(t.group(1)),
                            strip_tags(l.group(1)) if l else "",
                            strip_tags(d.group(1))[:400] if d else "",
                            parse_date(strip_tags(p.group(1)) if p else "")))
        return [o for o in out if o[0]]

    for item in root.iter("item"):
        title = (item.findtext("title") or "").strip()
        link = (item.findtext("link") or "").strip()
        desc = strip_tags(item.findtext("description") or "")[:400]
        when = parse_date((item.findtext("pubDate") or "").strip())
        if title:
            out.append((strip_tags(title), link, desc, when))

    ns = "{http://www.w3.org/2005/Atom}"
    for entry in root.findall(".//" + ns + "entry"):
        title_el = entry.find(ns + "title")
        link_el = entry.find(ns + "link")
        sum_el = entry.find(ns + "summary") if entry.find(ns + "summary") is not None else entry.find(ns + "content")
        upd = entry.find(ns + "published") if entry.find(ns + "published") is not None else entry.find(ns + "updated")
        title = (title_el.text or "").strip() if title_el is not None else ""
        link = link_el.get("href", "") if link_el is not None else ""
        desc = strip_tags(sum_el.text or "")[:400] if sum_el is not None else ""
        when = parse_date((upd.text or "").strip()) if upd is not None else None
        if title:
            out.append((strip_tags(title), link, desc, when))
    return out


def parse_date(raw):
    if not raw:
        return None
    raw = raw.strip()
    fmts = ["%a, %d %b %Y %H:%M:%S %z", "%a, %d %b %Y %H:%M:%S %Z",
            "%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%d %H:%M:%S"]
    for fmt in fmts:
        try:
            dt = datetime.strptime(raw, fmt)
            return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
        except ValueError:
            continue
    return None


def parse_relative_time(raw, now):
    """解析中文相对时间：12小时前 / 30分钟前 / 昨天 17:02 / 前天 15:51 / 2026-11-14"""
    if not raw:
        return None
    raw = raw.strip()
    m = re.match(r"(\d+)\s*分钟前", raw)
    if m:
        return now - timedelta(minutes=int(m.group(1)))
    m = re.match(r"(\d+)\s*小时前", raw)
    if m:
        return now - timedelta(hours=int(m.group(1)))
    m = re.match(r"(\d+)\s*天前", raw)
    if m:
        return now - timedelta(days=int(m.group(1)))
    m = re.match(r"昨天\s*(\d{1,2}):(\d{2})", raw)
    if m:
        d = (now - timedelta(days=1)).replace(hour=int(m.group(1)), minute=int(m.group(2)), second=0, microsecond=0)
        return d
    m = re.match(r"前天\s*(\d{1,2}):(\d{2})", raw)
    if m:
        d = (now - timedelta(days=2)).replace(hour=int(m.group(1)), minute=int(m.group(2)), second=0, microsecond=0)
        return d
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})", raw)
    if m:
        return datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)), tzinfo=CST)
    return None


def parse_html_news(html, base="https://www.qbitai.com"):
    """技能 Step 2 规定的 h2/h3/h4 + a 提取法，并关联卡片内的发布时间。"""
    now = datetime.now(CST)
    out = []
    # 优先按文章卡片解析，可同时拿到标题、链接与发布时间
    cards = re.findall(r'<div class="picture_text">(.*?)(?=<div class="picture_text">|\Z)', html, re.S)
    for card in cards:
        href = re.search(r'href="(' + re.escape(base) + r'/\d{4}/\d{2}/\d+\.html)"', card)
        title = re.search(r"<h[234][^>]*>(.*?)</h[234]>", card, re.S)
        t = re.search(r'<span class="time">\s*([^<]+?)\s*</span>', card)
        if not href or not title:
            continue
        title_text = strip_tags(title.group(1))
        if len(title_text) <= 6:
            continue
        when = parse_relative_time(t.group(1) if t else "", now)
        if when is None:
            m2 = re.search(r"/(\d{4})/(\d{2})/(\d+)\.html", href.group(1))
            if m2:
                # 只能取到年月，按当月该日 12:00 估算，仍标记为估算时间
                try:
                    when = datetime(int(m2.group(1)), int(m2.group(2)), 15, 12, 0, tzinfo=CST)
                except ValueError:
                    when = None
        out.append((title_text, href.group(1), "", when))

    if out:
        return out

    # 兜底：仅按标题层级提取（无时间）
    for tag, block in re.findall(r"<(h[234])[^>]*>(.*?)</\1>", html, re.I | re.S):
        links = re.findall(r'href="([^">]+)"', block)
        titles = re.findall(r">([^<]+)<", block)
        for link, title in zip(links, titles):
            title = strip_tags(title)
            if len(title) <= 6:
                continue
            if link.startswith("/"):
                link = base + link
            out.append((title, link, "", None))
    return out


def score_item(title, summary):
    text = (title + " " + summary).lower()
    total = 0
    for weight, kws in PRIORITY:
        if any(k in text for k in kws):
            total += weight
    return total


def is_ai_related(text):
    low = text.lower()
    return any(k in low for k in AI_HINT)


def norm(title):
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9\u4e00-\u9fff ]", "", title.lower())).strip()


def collect(window_hours, verbose):
    now = datetime.now(CST)
    cutoff = now - timedelta(hours=window_hours)
    items, report, seen = [], [], set()

    for src in SOURCES:
        if not src["ok"]:
            report.append({"source": src["name"], "status": "skipped", "reason": src["reason"], "count": 0})
            if verbose:
                print("  [SKIP] %-16s %s" % (src["name"], src["reason"]), file=sys.stderr)
            continue

        raw = fetch(src["url"])
        if raw is None:
            report.append({"source": src["name"], "status": "failed", "reason": "请求失败", "count": 0})
            if verbose:
                print("  [FAIL] %-16s 请求失败" % src["name"], file=sys.stderr)
            continue

        parsed = parse_html_news(raw) if src["kind"] == "html" else parse_rss(raw)
        kept = 0
        for title, link, summary, when in parsed:
            if len(title) <= 6:
                continue
            if not is_ai_related(title + " " + summary):
                continue
            key = norm(title)[:90]
            if not key or key in seen:
                continue
            # 无时间戳的条目（HTML 源）按抓取时刻计，并标注
            ts = when.astimezone(CST) if when else now
            if when and (ts < cutoff or ts > now + timedelta(hours=2)):
                continue
            seen.add(key)
            items.append({
                "title": title,
                "url": link,
                "summary": summary,
                "source": src["name"],
                "time": ts.strftime("%m-%d %H:%M"),
                "_ts": ts.timestamp(),
                "time_inferred": when is None,
                "score": score_item(title, summary),
            })
            kept += 1
        report.append({"source": src["name"], "status": "ok", "reason": None, "count": kept})
        if verbose:
            print("  [ OK ] %-16s %d 条" % (src["name"], kept), file=sys.stderr)

    items.sort(key=lambda x: (-x["score"], -x["_ts"]))
    return items, report, now, cutoff


def build_markdown(items, picked, now, source_report):
    day = now.strftime("%Y年%m月%d日")
    lines = ["# AI日报 - %s" % day, "", "## 重要新闻", ""]

    for i, it in enumerate(picked, 1):
        summary = it["summary"] or "（该源未提供摘要，标题为原文，详见链接。）"
        lines.append("### %d. %s" % (i, it["title"]))
        lines.append("**摘要**: %s" % summary)
        lines.append("**来源**: %s" % it["source"])
        lines.append("**原文**: [原文链接](%s)" % it["url"])
        lines.append("")

    rest = [x for x in items if x not in picked]
    industry = [x for x in rest if x["score"] >= 4][:6]
    products = [x for x in rest if x["score"] < 4][:6]

    lines.append("---")
    lines.append("")
    lines.append("## 行业动态")
    lines.append("")
    if industry:
        for it in industry:
            lines.append("- [%s](%s)（%s）" % (it["title"], it["url"], it["source"]))
    else:
        lines.append("- 本期窗口内未获取到更多行业动态。")
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 最新发布/产品")
    lines.append("")
    if products:
        for it in products:
            lines.append("- [%s](%s)（%s）" % (it["title"], it["url"], it["source"]))
    else:
        lines.append("- 本期窗口内未获取到新的产品发布信息。")
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("*本报告由 AI Daily Skill 自动生成*")
    lines.append("")
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="reports")
    ap.add_argument("--hours", type=int, default=24)
    ap.add_argument("--max", type=int, default=10, help="重要新闻条数上限")
    ap.add_argument("--min", type=int, default=5, help="重要新闻条数下限")
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    print("抓取窗口：最近 %d 小时" % args.hours, file=sys.stderr)
    items, source_report, now, cutoff = collect(args.hours, args.verbose)

    if not items:
        print("今日无法获取AI新闻，请稍后重试。", file=sys.stderr)
        return 1

    # 技能要求精选 5-10 条：按优先级取，且尽量覆盖不同来源
    picked, used_sources = [], set()
    for it in items:
        if len(picked) >= args.max:
            break
        if it["source"] in used_sources and len(picked) < args.min:
            continue
        picked.append(it)
        used_sources.add(it["source"])
    if len(picked) < args.min:
        for it in items:
            if len(picked) >= args.min:
                break
            if it not in picked:
                picked.append(it)

    stamp = now.strftime("%Y%m%d")
    md_path = os.path.join(args.out, "ai-daily-%s.md" % stamp)
    with open(md_path, "w", encoding="utf-8") as f:
        f.write(build_markdown(items, picked, now, source_report))

    side = os.path.join(args.out, ".items-%s.json" % stamp)
    with open(side, "w", encoding="utf-8") as f:
        json.dump({
            "generatedAt": now.strftime("%Y-%m-%d %H:%M"),
            "windowStart": cutoff.strftime("%Y-%m-%d %H:%M"),
            "windowEnd": now.strftime("%Y-%m-%d %H:%M"),
            "hours": args.hours,
            "picked": [it["title"] for it in picked],
            "items": [{k: v for k, v in it.items() if k != "_ts"} for it in items],
            "sourceReport": source_report,
        }, f, ensure_ascii=False, indent=2)

    ok = sum(1 for s in source_report if s["status"] == "ok")
    print("完成：%d 条候选，精选 %d 条，%d 个源可用 → %s" % (len(items), len(picked), ok, md_path), file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())