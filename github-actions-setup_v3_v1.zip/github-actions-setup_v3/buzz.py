#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
从当日新闻中提取高频实体，生成「今日热议」榜单。

设计原则：
- 只从当天实际抓到的标题/摘要中统计，不引入外部热度数据。
- 每个条目都带出处条数，可回溯核对，不是凭空打分。
- 实体词表人工维护，避免把普通词当成人名/公司名。
"""

import json
import re
from collections import Counter

# 实体词表：显示名 -> 匹配模式（不区分大小写）
# 类别：company=公司机构, tech=技术产品, event=事件类型
CATEGORY = {}

ENTITIES = [
    # 公司 / 机构
    ("英伟达", ["nvidia", "英伟达", "黄仁勋", "jensen huang"]),
    ("OpenAI", ["openai", "chatgpt", "奥特曼", "altman", "gpt-"]),
    ("Anthropic", ["anthropic", "claude", "阿莫代伊", "amodei"]),
    ("谷歌", ["google", "gemini", "谷歌", "deepmind", "alphabet"]),
    ("微软", ["microsoft", "微软", "copilot", "azure"]),
    ("Meta", ["meta ", "llama", "facebook", "扎克伯格"]),
    ("苹果", ["apple", "苹果公司", "siri"]),
    ("亚马逊", ["amazon", "aws", "亚马逊"]),
    ("特斯拉", ["tesla", "特斯拉", "马斯克", "musk", "spacex", "cybercab"]),
    ("DeepSeek", ["deepseek", "深度求索"]),
    ("阿里", ["alibaba", "阿里", "qwen", "千问", "通义"]),
    ("腾讯", ["tencent", "腾讯", "混元"]),
    ("字节跳动", ["bytedance", "字节", "豆包", "doubao", "tiktok"]),
    ("百度", ["baidu", "百度", "文心"]),
    ("华为", ["huawei", "华为", "昇腾"]),
    ("月之暗面", ["moonshot", "月之暗面", "kimi"]),
    ("智谱", ["zhipu", "智谱", "glm"]),
    ("MiniMax", ["minimax", "稀宇"]),
    ("xAI", ["xai", "grok"]),
    ("英特尔", ["intel", "英特尔"]),
    ("AMD", ["amd", "超威"]),
    ("台积电", ["tsmc", "台积电"]),
    ("三星", ["samsung", "三星"]),
    # 技术 / 产品
    ("大模型", ["大模型", "llm", "基础模型", "foundation model"]),
    ("智能体", ["agent", "智能体", "agentic"]),
    ("多模态", ["多模态", "multimodal"]),
    ("开源模型", ["开源", "open source", "open-source", "open weights"]),
    ("AI 芯片", ["芯片", "chip", "gpu", "算力卡", "accelerator"]),
    ("算力", ["算力", "compute", "data center", "数据中心"]),
    ("机器人", ["机器人", "robot", "具身", "humanoid", "embodied"]),
    ("自动驾驶", ["自动驾驶", "autonomous", "self-driving", "robotaxi"]),
    ("AI 编程", ["编程", "coding", "code", "developer", "ide"]),
    ("视频生成", ["视频生成", "video generation", "sora", "文生视频"]),
    ("AI 医疗", ["医疗", "health", "healthcare", "诊断"]),
    # 事件类型
    ("IPO / 上市", ["ipo", "上市", "路演", "挂牌"]),
    ("融资", ["融资", "funding", "raises", "seed round", "series"]),
    ("监管政策", ["监管", "政策", "法案", "regulation", "policy", "ban", "antitrust"]),
    ("裁员 / 组织调整", ["裁员", "layoff", "重组", "restructur", "解散", "disband"]),
    ("安全事件", ["漏洞", "攻击", "泄露", "security", "breach", "hack", "vulnerab"]),
]


# 需要词边界匹配的英文短词（否则 AgentGrid、codename 之类会误伤）
BOUNDARY_WORDS = {"agent", "code", "meta", "aws", "ban", "chip", "gpu", "llm", "ipo",
                  "moonshot", "kimi", "grok", "sora", "llama", "gemini", "claude",
                  "copilot", "azure", "apple", "siri", "tesla", "musk", "spacex",
                  "amazon", "intel", "amd", "tsmc", "samsung", "huawei", "tencent",
                  "baidu", "alibaba", "qwen", "glm", "minimax", "xai", "deepseek",
                  "openai", "anthropic", "nvidia", "google", "microsoft", "alphabet",
                  "deepmind", "chatgpt", "robot", "compute", "coding", "health",
                  "policy", "regulation", "breach", "hack", "security"}


def _hit(pattern, low):
    p = pattern.lower()
    if p.strip() in BOUNDARY_WORDS:
        # 严格词边界：前后不能紧邻英文字母，也不放宽复数
        # （放宽 s 会让 moonshots 命中 moonshot，属误伤）
        return re.search(r"(?<![a-z])" + re.escape(p) + r"(?![a-z])", low) is not None
    return p in low


COMPANY_NAMES = {"英伟达", "OpenAI", "Anthropic", "谷歌", "微软", "Meta", "苹果", "亚马逊",
                 "特斯拉", "DeepSeek", "阿里", "腾讯", "字节跳动", "百度", "华为",
                 "月之暗面", "智谱", "MiniMax", "xAI", "英特尔", "AMD", "台积电", "三星"}

EVENT_NAMES = {"IPO / 上市", "融资", "监管政策", "裁员 / 组织调整", "安全事件"}

for _n, _p in ENTITIES:
    if _n in COMPANY_NAMES:
        CATEGORY[_n] = "company"
    elif _n in EVENT_NAMES:
        CATEGORY[_n] = "event"
    else:
        CATEGORY[_n] = "tech"


def extract(text):
    """返回文本中命中的实体集合（同一实体只算一次）。"""
    low = text.lower()
    hits = set()
    for name, pats in ENTITIES:
        for p in pats:
            if _hit(p, low):
                hits.add(name)
                break
    return hits


def _sample(cand, name):
    """只有标题本身命中该实体时才作为样例展示，避免摘要命中导致图文不符。"""
    if not cand:
        return None
    if name not in extract(cand.get("title") or ""):
        return None
    return {k: v for k, v in cand.items() if k != "in_title"}


def build_buzz(news, top_n=8):
    """统计每个实体的提及条数、涉及来源与代表条目。"""
    score = Counter()
    hits = Counter()
    sources = {}
    samples = {}

    for item in news:
        title = item.get("title") or ""
        summary = item.get("summary") or ""
        in_title = extract(title)
        in_all = extract(title + " " + summary)
        for name in in_all:
            hits[name] += 1
            score[name] += 2 if name in in_title else 1
            src = item.get("source") or ""
            if src:
                sources.setdefault(name, set()).add(src)
            # 优先保留「标题直接命中」的条目作为代表，可读性更好
            cand = {"title": title, "url": item.get("url") or "",
                    "source": src, "time": item.get("time") or "",
                    "in_title": name in in_title}
            def rank(c):
                # 只接受标题命中；标题长度适中（12-70 字）再加分
                if not c["in_title"]:
                    return -1
                return 1 + (1 if 12 <= len(c["title"]) <= 70 else 0)

            prev = samples.get(name)
            if prev is None or rank(cand) > rank(prev):
                samples[name] = cand

    total = max(len(news), 1)
    out = []
    for name, sc in score.most_common(top_n):
        srcs = sorted(sources.get(name, set()))
        heat = sc + max(0, len(srcs) - 1) * 2
        out.append({
            "name": name,
            "count": hits[name],
            "sources": srcs,
            "ratio": round(hits[name] * 100.0 / total),
            "heat": heat,
            "category": CATEGORY.get(name, "tech"),
            "sample": _sample(samples.get(name), name),
        })
    out.sort(key=lambda x: (-x["heat"], -x["count"]))
    return out


if __name__ == "__main__":
    import sys
    data = json.load(open(sys.argv[1] if len(sys.argv) > 1 else "news.json", encoding="utf-8"))
    buzz = build_buzz(data.get("news") or [])
    print(json.dumps(buzz, ensure_ascii=False, indent=2))