#!/usr/bin/env python3
"""
每日更新任务（B 方案：日报驱动）
--------------------------------
流程：抓取 → 生成技能格式日报 → 转换 → 网页数据 news.json → 重建页面内联快照

    python3 daily_update.py

退出码：0 成功；1 失败（此时保留原有 news.json，页面不会变空）
"""

import json
import os
import re
import subprocess
import sys
from datetime import datetime, timedelta, timezone

CST = timezone(timedelta(hours=8))
BASE = os.path.dirname(os.path.abspath(__file__))
NEWS = os.path.join(BASE, "news.json")
PAGE = os.path.join(BASE, "ai-industry-map.html")
REPORTS = os.path.join(BASE, "reports")
LOG = os.path.join(BASE, "update.log")

MIN_ITEMS = 3


def log(msg):
    line = "[%s] %s" % (datetime.now(CST).strftime("%Y-%m-%d %H:%M:%S"), msg)
    print(line)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass


def run(script, args):
    proc = subprocess.run([sys.executable, script] + args, capture_output=True, text=True, cwd=BASE, timeout=900)
    for line in (proc.stderr or "").strip().splitlines():
        log("  " + line)
    return proc.returncode


def validate(path):
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    news = data.get("news") or []
    if len(news) < MIN_ITEMS:
        raise ValueError("条目过少（%d < %d），判定为抓取异常" % (len(news), MIN_ITEMS))
    for key in ("meta", "layers", "flow", "regions"):
        if key not in data:
            raise ValueError("缺少字段 %s" % key)
    if len(data["layers"]) != 4:
        raise ValueError("层级数量异常")
    return len(news)


def rebuild_page(news_path):
    """把最新的 news.json 内联进页面，保证离线打开也是当天数据。"""
    if not os.path.exists(PAGE):
        log("页面不存在，跳过内联")
        return
    html = open(PAGE, encoding="utf-8").read()
    payload = open(news_path, encoding="utf-8").read().replace("</", "<\\/")
    pattern = re.compile(r"(const FALLBACK = )(\{.*?\})(;\n\n\(function)", re.S)
    if not pattern.search(html):
        log("页面中未找到内联数据占位，跳过")
        return
    html = pattern.sub(lambda m: m.group(1) + payload + m.group(3), html, count=1)
    tmp = PAGE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(html)
    os.replace(tmp, PAGE)
    log("页面内联数据已刷新")


def main():
    log("开始更新（日报驱动）")

    if run("ai_daily_report.py", ["--out", "reports"]) != 0:
        log("日报生成失败，保留原有 news.json")
        return 1

    tmp = NEWS + ".tmp"
    if run("report_to_news.py", ["--out", tmp]) != 0:
        log("转换失败，保留原有 news.json")
        if os.path.exists(tmp):
            os.remove(tmp)
        return 1

    try:
        count = validate(tmp)
    except Exception as exc:
        log("校验未通过：%s，保留原有 news.json" % exc)
        if os.path.exists(tmp):
            os.remove(tmp)
        return 1

    os.replace(tmp, NEWS)  # 原子替换
    log("更新完成：%d 条 → %s" % (count, NEWS))
    rebuild_page(NEWS)
    return 0


if __name__ == "__main__":
    sys.exit(main())