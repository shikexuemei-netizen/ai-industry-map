#!/usr/bin/env python3
"""
日报 → 网页数据 转换器
----------------------
把 ai_daily_report.py 产出的 Markdown 日报（技能规定格式）转换成
网页 ai-industry-map.html 使用的 news.json 结构。

用法:
    python3 report_to_news.py                          # 用今天最新的日报
    python3 report_to_news.py --md reports/ai-daily-20261115.md
    python3 report_to_news.py --out news.json --verbose

输入:
    reports/ai-daily-YYYYMMDD.md     日报正文
    reports/.items-YYYYMMDD.json     时间/来源元数据（由 ai_daily_report.py 生成）

输出:
    news.json  包含 meta / news / buzz / signals / regions / layers / flow

设计取舍:
    - 只解析日报里真实存在的条目，不补造内容。
    - 摘要直接取自日报（技能输出，未改写）。
    - 「影响传导」字段不自动生成：那是需要人工判断的分析，自动写会变成编造。
      页面在缺少该字段时会自动隐藏对应区块。
    - 层级归类沿用关键词规则，无法可靠归类的标为「其他」，不硬塞。
"""

import argparse
import glob
import json
import os
import re
import sys
from datetime import datetime, timedelta, timezone

CST = timezone(timedelta(hours=8))

# 层级与环节关键词（与网页的四层结构一致）
LAYER_RULES = {
    "L1": ("基础设施", ["芯片", "gpu", "算力", "数据中心", "电力", "半导体", "晶圆", "封装",
                    "服务器", "chip", "semiconductor", "data center", "nvidia", "tsmc", "hbm"]),
    "L2": ("模型与算法", ["大模型", "模型", "llm", "gpt", "claude", "gemini", "deepseek", "qwen",
                     "开源", "训练", "微调", "多模态", "评测", "基准", "benchmark", "model"]),
    "L3": ("平台与工具链", ["api", "平台", "工具", "推理", "智能体", "agent", "部署", "编排",
                       "开发者", "sdk", "框架", "开源项目"]),
    "L4": ("应用与场景", ["应用", "产品", "上线", "发布", "用户", "企业", "助手", "机器人",
                     "终端", "手机", "汽车", "驾驶", "教育", "医疗", "app", "launch", "robot"]),
    "资本": ("资本", ["融资", "估值", "ipo", "上市", "收购", "并购", "营收", "财报",
                  "funding", "valuation", "acquire", "merger", "raises"]),
    "政策": ("政策", ["监管", "政策", "法案", "禁令", "政府", "合规", "regulation",
                  "policy", "ban", "antitrust", "senate"]),
    "安全": ("安全", ["安全", "漏洞", "攻击", "隐私", "泄露", "越权", "security",
                  "breach", "hack", "privacy", "leak"]),
}

SEGMENT_RULES = {
    "AI 芯片": ["芯片", "gpu", "accelerator", "nvidia", "算力卡"],
    "先进制程与封装": ["tsmc", "晶圆", "封装", "制程", "hbm", "foundry"],
    "AI 服务器与互联": ["服务器", "互联", "光模块", "server", "networking"],
    "数据中心与电力": ["数据中心", "电力", "制冷", "data center", "power"],
    "云算力与调度": ["云", "算力", "cloud", "compute", "租赁"],
    "基础大模型": ["大模型", "基础模型", "gpt", "claude", "gemini", "llama", "deepseek", "qwen", "开源模型"],
    "后训练与对齐": ["微调", "对齐", "后训练", "fine-tun", "rlhf"],
    "多模态模型": ["多模态", "生图", "视频生成", "语音", "视觉", "multimodal"],
    "垂类与小模型": ["垂类", "小模型", "行业模型", "端侧模型"],
    "评测与安全": ["评测", "基准", "benchmark", "红队", "安全测试"],
    "训练框架与调度": ["训练框架", "分布式训练", "pytorch", "cuda"],
    "推理服务与部署": ["推理", "部署", "延迟", "inference", "serving"],
    "数据工程与标注": ["数据集", "标注", "语料", "dataset", "annotation"],
    "智能体编排": ["智能体", "agent", "工具调用", "编排", "api"],
    "运维与可观测": ["监控", "故障", "可用性", "observability", "outage"],
    "通用助手": ["助手", "对话", "chatbot", "assistant", "app"],
    "办公与内容生产": ["办公", "文档", "会议", "内容生成", "设计"],
    "软件开发": ["编程", "代码", "开发者", "coding", "developer", "ide"],
    "行业解决方案": ["教育", "医疗", "金融", "制造", "政务", "课堂", "healthcare"],
    "端侧与硬件": ["端侧", "手机", "终端", "机器人", "汽车", "robot", "device"],
}

REGION_RULES = {
    "中国": ["中国", "国产", "北京", "上海", "深圳", "杭州", "量子位", "机器之心", "36氪",
           "deepseek", "qwen", "阿里", "腾讯", "百度", "字节", "华为"],
    "美国": ["美国", "硅谷", "openai", "anthropic", "nvidia", "google", "meta", "microsoft",
           "tesla", "techcrunch", "ars technica"],
    "欧洲": ["欧洲", "欧盟", "英国", "德国", "法国", "eu ", "europe", "mistral"],
}


def score(text, kws):
    low = text.lower()
    return sum(1 for k in kws if k.lower() in low)


def classify_layer(text):
    best, best_score = ("其他", "其他"), 0
    for code, (label, kws) in LAYER_RULES.items():
        s = score(text, kws)
        if s > best_score:
            best, best_score = (code, label), s
    return best


def classify_segments(text):
    hits = [(name, score(text, kws)) for name, kws in SEGMENT_RULES.items()]
    hits = [h for h in hits if h[1] > 0]
    hits.sort(key=lambda x: -x[1])
    return [h[0] for h in hits[:3]]


def classify_region(text):
    best, best_score = "全球", 0
    for region, kws in REGION_RULES.items():
        s = score(text, kws)
        if s > best_score:
            best, best_score = region, s
    return best


def parse_markdown(md_text):
    """解析技能规定格式的日报。返回 (news_items, industry_links, product_links)"""
    items, industry, products = [], [], []
    section = None

    # 重要新闻块：### N. 标题 / **摘要**: / **来源**: / **原文**: [原文链接](url)
    blocks = re.split(r"\n(?=###\s+\d+\.\s)", md_text)
    for block in blocks:
        m = re.match(r"###\s+\d+\.\s*(.+)", block.strip())
        if not m:
            continue
        title = m.group(1).strip()
        summ = re.search(r"\*\*摘要\*\*[:：]\s*(.+)", block)
        src = re.search(r"\*\*来源\*\*[:：]\s*(.+)", block)
        url = re.search(r"\*\*原文\*\*[:：]\s*\[[^\]]*\]\(([^)]+)\)", block)
        if not url:
            continue
        summary = summ.group(1).strip() if summ else ""
        if summary.startswith("（该源未提供摘要"):
            summary = ""
        items.append({
            "title": title,
            "summary": summary,
            "source": (src.group(1).strip() if src else "未知来源"),
            "url": url.group(1).strip(),
        })

    # 列表型条目
    for line in md_text.splitlines():
        if line.startswith("## "):
            head = line[3:].strip()
            section = "industry" if "行业动态" in head else ("product" if "发布" in head or "产品" in head else None)
            continue
        if section and line.strip().startswith("- ["):
            m = re.match(r"-\s*\[(.+?)\]\((.+?)\)(?:（(.+?)）)?", line.strip())
            if m:
                entry = {"title": m.group(1).strip(), "url": m.group(2).strip(), "source": (m.group(3) or "").strip()}
                (industry if section == "industry" else products).append(entry)

    return items, industry, products


def load_side_meta(reports_dir, stamp):
    path = os.path.join(reports_dir, ".items-%s.json" % stamp)
    if not os.path.exists(path):
        return {}
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        return {it["url"]: it for it in data.get("items", [])}
    except Exception:
        return {}


def build(news_items, industry, products, side, md_path, hours):
    now = datetime.now(CST)
    cutoff = now - timedelta(hours=hours)
    news = []

    def add(entry, is_key=False):
        text = entry["title"] + " " + entry.get("summary", "")
        meta = side.get(entry["url"], {})
        layer, label = classify_layer(text)
        when = meta.get("time") or now.strftime("%m-%d %H:%M")
        news.append({
            "id": re.sub(r"\W+", "-", entry["url"].rstrip("/").split("/")[-1] or entry["title"])[:40],
            "time": when,
            "layer": layer,
            "layerLabel": label,
            "tags": [label] if label != "其他" else [],
            "title": entry["title"],
            "summary": entry.get("summary") or "",
            "impact": "",
            "source": entry.get("source") or "未知来源",
            "url": entry["url"],
            "reliability": "reported",
            "key": is_key,
            "region": meta.get("region") or classify_region(text + " " + (entry.get("source") or "")),
            "segments": classify_segments(text),
            "timeInferred": meta.get("time_inferred", False),
        })

    for it in news_items:
        add(it, True)
    for it in industry:
        add(it, False)
    for it in products:
        add(it, False)

    # 去重（同一 URL 只留一条）
    seen, unique = set(), []
    for n in news:
        if n["url"] in seen:
            continue
        seen.add(n["url"])
        unique.append(n)

    # 今日热议榜：从当日条目中统计高频实体
    try:
        from buzz import build_buzz
        buzz = build_buzz(unique, top_n=8)
    except Exception:
        buzz = []

    regions = {}
    for n in unique:
        regions.setdefault(n["region"], []).append(n)
    region_cards = []
    for name in ["中国", "美国", "欧洲", "全球"]:
        bucket = regions.get(name, [])
        region_cards.append({
            "name": name,
            "label": "%d 条" % len(bucket) if bucket else "当日无新增",
            "items": [{"b": n["title"][:40], "p": (n["summary"][:90] + "…") if len(n["summary"]) > 90 else (n["summary"] or n["source"])}
                      for n in bucket[:4]],
            "empty": None if bucket else "本期日报中未收录该地区的条目。",
        })

    # 复用页面已有的四层结构与链路说明
    layers, flow = load_page_structure()

    return {
        "meta": {
            "generatedAt": now.strftime("%Y-%m-%d %H:%M") + " (北京时间)",
            "windowStart": cutoff.strftime("%Y-%m-%d %H:%M"),
            "windowEnd": now.strftime("%Y-%m-%d %H:%M"),
            "windowLabel": cutoff.strftime("%m-%d %H:%M") + " — " + now.strftime("%m-%d %H:%M") + "（北京时间，%d 小时）" % hours,
            "sourceNote": "由 ai-daily-report-skill 规范生成的日报转换而来：%s" % os.path.basename(md_path),
            "autoGenerated": True,
            "generator": "ai_daily_report.py + report_to_news.py",
        },
        "news": unique,
        "buzz": buzz,
        "signals": [],
        "regions": region_cards,
        "layers": layers,
        "flow": flow,
    }


FALLBACK_LAYERS = [
    {"id": "l1", "tab": "tab-l1", "code": "L1", "name": "基础设施层",
     "summary": "为模型训练与推理提供算力、网络与能源，是整条产业链最靠近物理约束的一层。",
     "segments": [
         {"name": "AI 芯片", "meta": "算力供给", "def": "承担大模型训练与推理的主力计算器件，通常指 GPU、加速卡与自研 AI 专用芯片，也包括配套的高带宽显存与互联接口。", "tech": ["高带宽显存", "张量计算单元", "卡间互联", "低精度计算"], "players": "芯片设计公司、晶圆代工与封测厂、云厂商自研芯片团队、板卡与整机集成商。", "up": "先进制程产能、封装能力、显存与互联 IP，是本环节最直接的瓶颈。", "down": "为 AI 服务器与云算力平台提供算力单元，决定训练集群的规模上限。"},
         {"name": "先进制程与封装", "meta": "制造环节", "def": "把芯片设计变成可量产器件的过程，包含先进制程节点、先进封装与高带宽存储的集成能力。", "tech": ["先进制程", "2.5D / 3D 封装", "高带宽存储堆叠", "良率控制"], "players": "晶圆代工厂、封装测试厂、存储厂商、半导体设备与材料供应商。", "up": "光刻与刻蚀设备、特种材料、EDA 工具，供给集中度高。", "down": "向芯片设计公司交付晶圆与成品器件，产能分配直接影响下游节奏。"},
         {"name": "AI 服务器与互联", "meta": "系统集成", "def": "把加速卡、CPU、内存、存储与网络组装成可部署的算力单元，并用高速网络把它们连成集群。", "tech": ["高速互联", "集群网络拓扑", "液冷散热", "整机柜交付"], "players": "服务器整机厂商、网络设备厂商、光模块与线缆供应商、系统集成商。", "up": "依赖芯片与存储的供给，以及电源、散热等配套件的交付。", "down": "向数据中心与云平台交付可运行的训练或推理集群。"},
         {"name": "数据中心与电力", "meta": "物理承载", "def": "提供机房、供电、制冷与网络接入的物理场所，是算力真正落地的位置。", "tech": ["高密度机柜", "液冷与余热回收", "绿电接入", "园区选址"], "players": "第三方数据中心运营商、云厂商自建园区、电力与能源企业、地方政府与园区方。", "up": "受电网容量、土地与能耗指标约束，审批与建设周期长。", "down": "为云算力平台提供机位与电力，决定可用算力的地理分布。"},
         {"name": "云算力与调度", "meta": "算力服务", "def": "把分散的加速卡资源池化，按需分配给训练与推理任务，并提供计费、配额与弹性伸缩能力。", "tech": ["资源池化", "任务调度", "弹性伸缩", "多租户隔离"], "players": "公有云厂商、算力租赁服务商、智算中心运营方、企业私有云团队。", "up": "依赖服务器与数据中心的交付，以及电力与网络成本。", "down": "向模型团队与应用开发者提供按需算力，是训练与推理的直接供给方。"},
     ]},
    {"id": "l2", "tab": "tab-l2", "code": "L2", "name": "模型与算法层",
     "summary": "把算力与数据转化为可复用的能力：理解语言、图像与声音，并按任务做后训练与评测。",
     "segments": [
         {"name": "基础大模型", "meta": "通用能力", "def": "在海量语料上预训练得到的大规模参数模型，提供语言理解、生成与一定的推理能力，是多数上层应用的能力底座。", "tech": ["预训练", "上下文窗口", "混合专家结构", "长文本处理"], "players": "模型研发公司、云厂商与大型科技企业的模型团队、开源模型社区。", "up": "依赖大规模训练算力、语料与数据治理能力，训练成本以千万美元计。", "down": "通过 API 或开源权重向平台与应用层输出通用能力。"},
         {"name": "后训练与对齐", "meta": "能力调优", "def": "在基础模型之上做指令微调、偏好对齐与强化学习，让模型更符合任务要求与使用规范。", "tech": ["指令微调", "偏好对齐", "强化学习", "蒸馏压缩"], "players": "模型公司后训练团队、高校与研究机构、面向企业的模型服务商。", "up": "依赖基础模型权重、高质量标注数据与评测反馈。", "down": "向垂类模型与应用提供更可控、更稳定的模型版本。"},
         {"name": "多模态模型", "meta": "跨模态能力", "def": "同时处理文本、图像、音频与视频的模型，让系统能看懂画面、听懂语音并生成多种形态的内容。", "tech": ["视觉编码", "语音识别与合成", "视频理解", "跨模态对齐"], "players": "模型研发公司、语音与视觉技术企业、内容平台的技术团队。", "up": "依赖多模态语料、算力与跨模态标注数据。", "down": "为内容生产、客服、质检、无障碍等场景提供能力输入。"},
         {"name": "垂类与小模型", "meta": "场景适配", "def": "针对特定行业或设备条件优化的模型，参数规模更小，追求在有限算力下的稳定表现与可控成本。", "tech": ["领域微调", "模型压缩", "端侧推理", "私有化部署"], "players": "行业软件厂商、行业模型公司、企业与科研机构的算法团队。", "up": "依赖基础模型或开源权重，以及行业知识与业务数据。", "down": "为行业应用与端侧设备提供可部署的模型能力。"},
         {"name": "评测与安全", "meta": "质量约束", "def": "用基准测试、人工评审与红队测试衡量模型能力边界，并处理幻觉、越权与内容安全问题。", "tech": ["基准测试", "红队测试", "内容过滤", "可解释性"], "players": "评测机构与榜单维护方、模型公司的安全团队、第三方合规服务商。", "up": "依赖可复现的测试集、标注人力与算力预算。", "down": "为模型选型、上线审批与合规审查提供依据。"},
     ]},
    {"id": "l3", "tab": "tab-l3", "code": "L3", "name": "平台与工具链层",
     "summary": "把模型和算力变成工程上可用的系统：训练、部署、数据、编排与运维，都在这一层完成。",
     "segments": [
         {"name": "训练框架与调度", "meta": "训练工程", "def": "支撑大规模分布式训练的软件栈，负责并行切分、通信优化与故障恢复，决定算力能被利用到什么程度。", "tech": ["分布式并行", "通信优化", "容错重启", "显存优化"], "players": "框架与开源社区、云厂商训练平台团队、企业内部 AI 基础架构团队。", "up": "依赖集群硬件拓扑与高速网络，对互联带宽敏感。", "down": "向模型团队提供可用的训练效率，直接决定训练周期与成本。"},
         {"name": "推理服务与部署", "meta": "服务化", "def": "把训练好的模型变成可调用的在线服务，处理批处理、缓存、量化与弹性扩容，直接影响响应速度和单价。", "tech": ["连续批处理", "量化与蒸馏", "KV 缓存", "弹性扩容"], "players": "推理服务商、云厂商模型服务平台、开源推理引擎社区。", "up": "依赖模型权重、加速卡与调度资源。", "down": "向应用层提供 API 与 SDK，是应用体验与成本的直接来源。"},
         {"name": "数据工程与标注", "meta": "数据供给", "def": "负责数据的采集、清洗、脱敏、标注与版本管理，为预训练、微调与评测提供可用数据。", "tech": ["数据清洗", "脱敏与合规", "标注管理", "数据版本化"], "players": "数据服务商、标注平台、企业数据团队、行业数据持有方。", "up": "依赖可授权的数据来源与合规审查，行业数据往往不公开流通。", "down": "向模型训练与评测提供语料和标注结果，质量决定模型上限。"},
         {"name": "智能体编排", "meta": "任务编排", "def": "把模型、工具、检索与业务流程串成可执行的任务链，让系统能调外部接口、查资料并分步完成目标。", "tech": ["工具调用", "检索增强", "多步规划", "状态与记忆"], "players": "应用平台厂商、企业软件厂商、开源编排框架社区、系统集成商。", "up": "依赖模型能力与稳定的工具接口，也依赖企业内部系统的开放程度。", "down": "向应用层输出可执行的工作流，是应用从问答走向办事的关键。"},
         {"name": "运维与可观测", "meta": "运行保障", "def": "对模型服务做监控、日志、评测回归与成本核算，让系统在上线后仍能被度量、排障和优化。", "tech": ["调用追踪", "效果回归", "成本计量", "告警与限流"], "players": "可观测性厂商、云厂商运维平台、企业 SRE 与平台工程团队。", "up": "依赖推理服务的埋点与日志规范，以及统一的评测基线。", "down": "向应用与业务方提供稳定性、成本与效果三类可度量指标。"},
     ]},
    {"id": "l4", "tab": "tab-l4", "code": "L4", "name": "应用与场景层",
     "summary": "直接面向用户与业务的一层，把模型能力包装成产品、工作流与行业解决方案。",
     "segments": [
         {"name": "通用助手", "meta": "面向个人", "def": "以对话为入口的通用产品，覆盖问答、写作、检索与简单任务处理，是多数用户第一次接触 AI 的方式。", "tech": ["对话交互", "联网检索", "多轮上下文", "个性化记忆"], "players": "模型公司的自有产品、独立 AI 产品团队、超级应用内的 AI 入口。", "up": "依赖模型 API 与推理成本，也依赖检索与内容生态。", "down": "向个人用户直接交付体验，用户规模反向影响模型迭代的数据与收入。"},
         {"name": "办公与内容生产", "meta": "面向企业", "def": "嵌入文档、会议、设计与营销流程的 AI 能力，把生成与整理工作放进已有的协作工具里。", "tech": ["文档生成", "会议纪要", "图像与视频生成", "流程嵌入"], "players": "办公软件厂商、创意设计工具厂商、内容平台与营销服务商。", "up": "依赖模型能力与既有产品的用户基数，以及企业数据的接入授权。", "down": "向企业客户按席位或用量交付，是当前较容易看到付费意愿的场景。"},
         {"name": "软件开发", "meta": "生产工具", "def": "把 AI 用于写代码、读代码、测试与运维，改变研发流程中的分工与节奏。", "tech": ["代码补全", "仓库级理解", "自动测试", "缺陷定位"], "players": "代码编辑器与 IDE 厂商、代码托管平台、企业研发效能团队。", "up": "依赖模型的长上下文与代码能力，以及企业内部代码库的接入方式。", "down": "向研发团队交付效率工具，效果可以直接用交付速度衡量。"},
         {"name": "行业解决方案", "meta": "垂直落地", "def": "面向金融、医疗、制造、政务等行业的定制化系统，需要把模型能力与行业流程、合规要求一起交付。", "tech": ["行业知识库", "私有化部署", "流程集成", "合规审计"], "players": "行业软件厂商、系统集成商、行业模型公司、企业与公共机构的信息化部门。", "up": "依赖垂类模型、行业数据与客户既有系统的开放程度。", "down": "向行业客户交付可验收的系统，项目周期长但客单价高。"},
         {"name": "端侧与硬件", "meta": "设备载体", "def": "把模型放进手机、PC、汽车与可穿戴设备，在本地完成推理，换取低延迟与数据不出端。", "tech": ["端侧推理", "模型压缩", "芯片 NPU", "离线能力"], "players": "终端设备厂商、芯片厂商的 NPU 团队、操作系统与生态方。", "up": "依赖小模型能力与端侧算力，受功耗、内存与散热限制。", "down": "向用户交付预装 AI 能力的设备，也向应用层开放本地接口。"},
     ]},
]

FALLBACK_FLOW = [
    {"name": "用户发起请求", "layer": "应用与场景层", "text": "用户在应用里提出问题或下达任务。应用需要判断这是闲聊、检索、还是需要调用外部工具的复杂任务，并决定用哪个模型、带多少上下文。", "limit": "上下文长度与成本预算：塞进更多资料会提升准确率，也会抬高每次请求的费用。", "risk": "答非所问或答得太笼统，通常先表现为应用侧的提示与检索设计问题，而不是模型不行。"},
    {"name": "请求进入推理服务", "layer": "平台与工具链层", "text": "请求通过 API 进入推理服务，排队、批处理、命中缓存，再被分配到具体的模型实例上。这一层决定排队要多久、一次请求花多少钱。", "limit": "并发与显存：批处理能提高吞吐，但会拉长单次响应时间。", "risk": "高峰期首字延迟变长、超时重试增加，业务侧看到的是卡顿而不是报错。"},
    {"name": "调度到算力资源", "layer": "基础设施层", "text": "推理任务被调度到具体的加速卡上执行。资源池是否充足、卡与卡之间的网络是否通畅，决定了能不能接住这波请求。", "limit": "算力供给与电力：集群扩容要经过采购、交付与上电，周期以季度计。", "risk": "资源不足时会触发排队或限流，应用侧表现为功能降级或排队提示。"},
    {"name": "模型完成计算", "layer": "模型与算法层", "text": "模型读取上下文，逐字生成结果。回答质量取决于模型能力、上下文质量与解码策略，也取决于是否针对该任务做过后训练。", "limit": "能力边界：模型对训练数据之外的事实与专业细节并不可靠，需要外部资料约束。", "risk": "出现幻觉或格式不符，往往需要检索增强、约束解码或换用更强的模型来修正。"},
    {"name": "结果回传与计量", "layer": "平台与工具链层", "text": "生成结果被组装、过滤、缓存，并按 token 计量。工具调用产生的外部结果也会在这一步被合并进上下文。", "limit": "内容安全与计费准确性：过滤会损失部分输出，计量误差会直接影响毛利。", "risk": "成本失控往往在这里才被发现：单次请求不贵，规模化之后账单增长很快。"},
    {"name": "应用呈现与沉淀", "layer": "应用与场景层", "text": "结果被渲染给用户，同时写入日志与反馈。这些使用数据会回流到评测与产品迭代，形成下一轮的改进依据。", "limit": "反馈质量：用户很少主动评价，沉默不等于满意。", "risk": "缺少评测基线时，模型升级可能悄悄降低体验，而团队无法察觉。"},
]


def load_page_structure():
    """优先取现有结构，取不到则用内置兜底，保证任何目录都能独立运行。"""
    here = os.path.dirname(os.path.abspath(__file__))
    for name in ["news.json", "structure.json"]:
        path = os.path.join(here, name)
        if os.path.exists(path):
            try:
                with open(path, encoding="utf-8") as f:
                    data = json.load(f)
                if data.get("layers") and data.get("flow"):
                    return data["layers"], data["flow"]
            except Exception:
                pass
    # 兜底：从页面内联的 FALLBACK 中提取
    page = os.path.join(here, "ai-industry-map.html")
    if os.path.exists(page):
        html = open(page, encoding="utf-8").read()
        m = re.search(r"const FALLBACK = (\{.*?\});\n\n\(function", html, re.S)
        if m:
            data = json.loads(m.group(1).replace("<\\/", "</"))
            return data["layers"], data["flow"]
    return FALLBACK_LAYERS, FALLBACK_FLOW


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--md", default=None, help="日报 Markdown 路径，默认取 reports/ 下最新")
    ap.add_argument("--out", default="news.json")
    ap.add_argument("--hours", type=int, default=24)
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args()

    md_path = args.md
    if not md_path:
        cands = sorted(glob.glob("reports/ai-daily-*.md"))
        if not cands:
            print("未找到日报文件，请先运行 ai_daily_report.py", file=sys.stderr)
            return 1
        md_path = cands[-1]

    md_text = open(md_path, encoding="utf-8").read()
    news_items, industry, products = parse_markdown(md_text)
    if args.verbose:
        print("解析：重要新闻 %d 条，行业动态 %d 条，产品 %d 条" % (len(news_items), len(industry), len(products)),
              file=sys.stderr)

    stamp = re.search(r"(\d{8})", os.path.basename(md_path))
    side = load_side_meta(os.path.dirname(md_path) or ".", stamp.group(1)) if stamp else {}

    data = build(news_items, industry, products, side, md_path, args.hours)
    if not data["news"]:
        print("日报中没有可转换的条目", file=sys.stderr)
        return 1

    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    print("转换完成：%d 条 → %s" % (len(data["news"]), args.out), file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())